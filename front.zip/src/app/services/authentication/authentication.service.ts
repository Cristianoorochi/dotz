import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router, ActivatedRoute } from '@angular/router';


@Injectable({ providedIn: 'root' })
export class AuthenticationService {
    constructor(private http: HttpClient, private router: Router) { }

    url = "http://localhost:3000/profile";

    getUsuario() {
        return this.http.get(this.url);
    }

    getLogin(id: any) {
        return this.http.get(`${this.url}/${id}`);
    }

    saveUsuario(user: any){
        return this.http.post(this.url, {
          nome: user.value.nome,
          email: user.value.email,
          cpf: user.value.cpf,
          endereco: [
            {
                rua: user.value.rua,
                numero: user.value.numero,
                bairro: user.value.bairro,
                cidade: user.value.cidade,
                uf: user.value.uf,
                cep: user.value.cep
            }
          ],
          saldo: 0,
          produtos: []
        });
    }

    updateResgate(id: any, dados: any){
        return this.http.put(`${this.url}/${id}`, dados);
    }

}