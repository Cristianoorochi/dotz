import { HttpClient } from '@angular/common/http'; 
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})


export default class ProdutosService {
    url = "http://localhost:3000/produtos";


    constructor(private http: HttpClient){ }

    getProdutos(){
        return this.http.get(this.url);
    }

}