import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import Swal from 'sweetalert2';
import { AuthenticationService } from 'src/app/services/authentication/authentication.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  loginForm: FormGroup;
  cadastroForm: FormGroup;
  olho = false;
  olhoNovo = false;
  cadastro = false;
  endereco = false;
  

  constructor(
    private formBuilder: FormBuilder,
    private router: Router,
    private authenticationService: AuthenticationService
  ) {
    this.loginForm = this.formBuilder.group({
      login: ['', [Validators.required, Validators.email]]
    });

    this.cadastroForm = this.formBuilder.group({
      cpf: ['', [Validators.required]],
      email: ['', [Validators.required, Validators.email]],
      rua: ['', Validators.required],
      numero: ['', Validators.required],
      bairro: ['', Validators.required],
      cep: ['', [Validators.required]],
      cidade: ['', Validators.required],
      uf: ['', Validators.required]
    });
  }

  // Reconhece os campos
  get login() {
    return this.loginForm.get('login');
  }
  get cpf() {
    return this.cadastroForm.get('cpf');
  }
  get email() {
    return this.cadastroForm.get('email');
  }
  get rua() {
    return this.cadastroForm.get('rua');
  }
  get numero() {
    return this.cadastroForm.get('numero');
  }
  get bairro() {
    return this.cadastroForm.get('bairro');
  }
  get cidade() {
    return this.cadastroForm.get('cidade');
  }
  get uf() {
    return this.cadastroForm.get('uf');
  }
  get cep() {
    return this.cadastroForm.get('cep');
  }

  ngOnInit(): void {
  }

  submit(form: any) {

    if (this.loginForm.valid) {
      this.authenticationService
      .getUsuario()
      .subscribe( res => {
        let arr: any;

        if(Array.isArray(res)){
          arr = res.filter(
            res => res.email === this.loginForm.value.login
          );
        }
        localStorage.setItem('userDotz', arr[0]?.id);

        this.authenticationService
        .getLogin(arr[0]?.id)
        .subscribe( resu => {
          this.router.navigate(['/inicio']);
          setTimeout( () => {location.reload()},200);

        }, err => {
          Swal.fire('Acesso', 'Usuário incorreto!', 'error');
        })

      })
    }
  }


  salvarCadastro() {
    if(this.cadastroForm.valid){
      this.cadastro = false;

      this.authenticationService
      .saveUsuario(this.cadastroForm)
      .subscribe( res => {
        Swal.fire(
          'Dotz',
          `Cadastro efetuado com sucesso, entre com o email cadastrado para acessar o sistema.`,
          'success'
        ).then(() => {
          this.router.navigate(['/login']);
        });
        
      }, err => {
        console.log(err);
      })
      
    }

  }

}
