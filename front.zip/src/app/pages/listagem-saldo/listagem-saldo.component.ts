import { Component, OnInit } from '@angular/core';
import ProdutosService from '../../services/produtos/produtos.service';
import { AuthenticationService } from 'src/app/services/authentication/authentication.service';
import Swal from 'sweetalert2';
import {ModalDismissReasons, NgbModal} from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-listagem-saldo',
  templateUrl: './listagem-saldo.component.html',
  styleUrls: ['./listagem-saldo.component.scss']
})
export class ListagemSaldoComponent implements OnInit {
  public usuario: any;
  public produtos: any;
  public filtro: any = '';
  public closeModal: string = '';
  public resgate: any;

  constructor(private produtosService: ProdutosService,
              private user: AuthenticationService,
              private modalService: NgbModal
    ) { }

  ngOnInit(): void {
  }

  ngAfterViewInit() {
    this.obterProdutos();
    this.obterUsuario();
    
  }

  obterUsuario() {
    this.user
    .getLogin(localStorage.getItem('userDotz'))
    .subscribe( resul => {
      this.usuario = resul;
    })
  }

  obterProdutos() {
    this.produtosService
    .getProdutos()
    .subscribe( res => {
      this.produtos = res;

      this.user
      .getLogin(localStorage.getItem('userDotz'))
      .subscribe( (resul: any) => {
        this.produtos.map((el:any) => {
          resul.produtos.map((ele:any) => {
            if(el.id === ele.id){
              el.resgatado = true;
            }
          })
        })

      })

    }, err => {
      console.log(err);
    })
  }

  filtrar() {
    if(this.filtro === ''){
      this.obterProdutos();
    }

    this.produtos = this.produtos.filter( (el: any) => {
      return el.setor === this.filtro
    })

  }


  resgatar(produto:any){
    let dados;

    if(this.usuario.saldo < produto.valor){
      Swal.fire('Resgate', 'Você não possui saldo suficiente para o resgate', 'error');
      return;
    }

    let prod = this.usuario.produtos.map( (el: any) => {
      return el
    })

    prod.push({
      id: produto.id,
      nome: produto.nome,
      valor: produto.valor,
      data: new Date()
    })

    dados = {
      email: this.usuario.email,
      cpf: this.usuario.cpf,
      endereco: [
        {
          rua: this.usuario.endereco[0].rua,
          numero: this.usuario.endereco[0].numero,
          bairro: this.usuario.endereco[0].bairro,
          cidade: this.usuario.endereco[0].cidade,
          uf: this.usuario.endereco[0].uf,
          cep: this.usuario.endereco[0].cep
        }
      ],
      id: this.usuario.id,
      saldo: this.usuario.saldo - produto.valor,
      produtos: prod
    }

    this.user
    .updateResgate(this.usuario.id, dados)
    .subscribe( res => {
      Swal.fire('Resgate', 'resgate efetuado com sucesso.', 'success');
      this.obterUsuario();
      this.obterProdutos();
    }, err => {
      Swal.fire('Resgate', 'Houve um erro no resgate', 'error');
    })
  }


  triggerModal(content: any) {
    this.modalService.open(content, {ariaLabelledBy: 'modal-basic-title'}).result.then((res) => {
      this.closeModal = `Closed with: ${res}`;
    }, (res) => {
      this.closeModal = `Dismissed ${this.getDismissReason(res)}`;
    });
  }


  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return  `with: ${reason}`;
    }
  }


  dadosResgate(produto:any) {
    this.resgate = produto;
    this.resgate.data = this.usuario.produtos.find((ele:any) => {
      return ele.id === produto.id
    })
  }

}
