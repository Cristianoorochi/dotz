const chalk = require('chalk')

console.log(
  'Like JSON Server? You can support the project on',
  chalk.bold('GitHub Sponsors')
)
console.log(
  chalk.underline('https://github.com/users/typicode/sponsorship'),
  chalk.red('❤')
)
